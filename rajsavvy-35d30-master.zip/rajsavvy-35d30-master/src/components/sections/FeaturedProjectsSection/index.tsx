import ProjectFeedSection from '../ProjectFeedSection';
export default function FeaturedProjectsSection(props) {
    return <ProjectFeedSection {...props} annotateProjects={true} />;
}
