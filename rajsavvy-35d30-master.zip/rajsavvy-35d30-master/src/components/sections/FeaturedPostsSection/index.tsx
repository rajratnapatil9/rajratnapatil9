import PostFeedSection from '../PostFeedSection';
export default function FeaturedPostSection(props) {
    return <PostFeedSection {...props} annotatePosts={true} />;
}
